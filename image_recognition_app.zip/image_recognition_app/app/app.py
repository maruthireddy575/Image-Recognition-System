
import os
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename

import numpy as np

from tensorflow.keras.models import load_model
from tensorflow.keras.applications.mobilenet_v2 import MobileNetV2, decode_predictions

from .utils import read_imagefile_to_bgr, preprocess_bgr_for_model, load_labels

UPLOAD_FOLDER = os.environ.get("UPLOAD_FOLDER", "uploads")
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "bmp"}

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("FLASK_SECRET_KEY", "dev-secret")
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# -------- Model loading logic --------
MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "models", "model.h5")
LABELS_PATH = os.path.join(os.path.dirname(__file__), "..", "models", "labels.txt")

use_imagenet = True
labels = None

if os.path.exists(MODEL_PATH) and os.path.getsize(MODEL_PATH) > 0 and os.path.exists(LABELS_PATH):
    try:
        model = load_model(MODEL_PATH)
        labels = load_labels(LABELS_PATH)
        use_imagenet = False
        print(f"[INFO] Loaded custom model with {len(labels)} classes.")
    except Exception as e:
        print(f"[WARN] Could not load custom model, falling back to ImageNet. Reason: {e}")
        model = MobileNetV2(weights="imagenet")
        use_imagenet = True
else:
    model = MobileNetV2(weights="imagenet")

def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    if "image" not in request.files:
        flash("No file part")
        return redirect(url_for("index"))

    file = request.files["image"]
    if file.filename == "":
        flash("No selected file")
        return redirect(url_for("index"))

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        save_path = os.path.join(app.config["UPLOAD_FOLDER"], f"{datetime.utcnow().timestamp()}_{filename}")
        file_bytes = file.read()

        # Save original upload
        with open(save_path, "wb") as f:
            f.write(file_bytes)

        # OpenCV + preprocess
        try:
            img_bgr = read_imagefile_to_bgr(file_bytes)
            x = preprocess_bgr_for_model(img_bgr, target_size=(224, 224))
        except Exception as e:
            flash(f"Error reading image: {e}")
            return redirect(url_for("index"))

        # Predict
        preds = model.predict(x)
        top_k = 5

        if use_imagenet:
            decoded = decode_predictions(preds, top=top_k)[0]
            results = [{"label": lbl, "name": name.replace("_", " "), "score": float(score)} for (lbl, name, score) in decoded]
        else:
            # Custom model
            probs = preds[0]
            top_idxs = np.argsort(probs)[::-1][:top_k]
            results = [{"label": labels[i], "name": labels[i], "score": float(probs[i])} for i in top_idxs]

        return render_template("index.html", results=results, image_path=os.path.basename(save_path))

    flash("Unsupported file type. Please upload a PNG/JPG/JPEG/BMP file.")
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=True)
