
import io
import cv2
import numpy as np
from typing import Tuple
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input

def read_imagefile_to_bgr(file_bytes: bytes) -> np.ndarray:
    """Read raw image bytes into an OpenCV BGR array."""
    file_arr = np.frombuffer(file_bytes, dtype=np.uint8)
    img = cv2.imdecode(file_arr, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("Could not decode image. Please upload a valid image file.")
    return img

def preprocess_bgr_for_model(img_bgr: np.ndarray, target_size: Tuple[int, int]=(224, 224)) -> np.ndarray:
    """Resize, convert BGR->RGB, preprocess for MobileNetV2-compatible models."""
    img_resized = cv2.resize(img_bgr, target_size, interpolation=cv2.INTER_AREA)
    img_rgb = cv2.cvtColor(img_resized, cv2.COLOR_BGR2RGB)
    x = np.expand_dims(img_rgb.astype(np.float32), axis=0)
    x = preprocess_input(x)
    return x

def load_labels(labels_path: str):
    """Load class labels (one per line)."""
    with open(labels_path, "r", encoding="utf-8") as f:
        labels = [line.strip() for line in f if line.strip()]
    return labels
