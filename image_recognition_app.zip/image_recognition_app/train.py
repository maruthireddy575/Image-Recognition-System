
"""
Train a transfer-learning image classifier using MobileNetV2 as a base.
Expected dataset layout:

data/
  train/
    class_a/
      img1.jpg
      ...
    class_b/
      ...
  val/
    class_a/
    class_b/

Usage:
    python train.py --epochs 5 --img-size 224 --batch-size 32 --lr 0.0005

Outputs:
    models/model.h5
    models/labels.txt
"""

import os
import argparse
from pathlib import Path

import tensorflow as tf
from tensorflow.keras import layers, models, optimizers
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping, ReduceLROnPlateau

def build_datasets(data_dir="data", img_size=224, batch_size=32):
    train_dir = os.path.join(data_dir, "train")
    val_dir = os.path.join(data_dir, "val")

    train_ds = tf.keras.preprocessing.image_dataset_from_directory(
        train_dir,
        label_mode="categorical",
        image_size=(img_size, img_size),
        batch_size=batch_size,
        shuffle=True
    )

    val_ds = tf.keras.preprocessing.image_dataset_from_directory(
        val_dir,
        label_mode="categorical",
        image_size=(img_size, img_size),
        batch_size=batch_size,
        shuffle=False
    )

    class_names = train_ds.class_names

    # Performance options
    AUTOTUNE = tf.data.AUTOTUNE
    train_ds = train_ds.prefetch(buffer_size=AUTOTUNE)
    val_ds = val_ds.prefetch(buffer_size=AUTOTUNE)

    # Preprocessing to match MobileNetV2
    preprocess = tf.keras.applications.mobilenet_v2.preprocess_input

    def _preprocess(image, label):
        image = tf.cast(image, tf.float32)
        image = preprocess(image)
        return image, label

    train_ds = train_ds.map(_preprocess, num_parallel_calls=AUTOTUNE)
    val_ds = val_ds.map(_preprocess, num_parallel_calls=AUTOTUNE)

    return train_ds, val_ds, class_names

def build_model(num_classes: int, img_size=224, lr=5e-4, train_base=False):
    base = MobileNetV2(input_shape=(img_size, img_size, 3), include_top=False, weights="imagenet")
    base.trainable = train_base  # freeze base by default

    inputs = layers.Input(shape=(img_size, img_size, 3))
    x = base(inputs, training=False)
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(0.2)(x)
    outputs = layers.Dense(num_classes, activation="softmax")(x)

    model = models.Model(inputs, outputs)
    opt = optimizers.Adam(learning_rate=lr)
    model.compile(optimizer=opt, loss="categorical_crossentropy", metrics=["accuracy"])
    return model

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=str, default="data")
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--img-size", type=int, default=224)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--lr", type=float, default=5e-4)
    parser.add_argument("--train-base", action="store_true", help="Fine-tune the convolutional base")
    args = parser.parse_args()

    train_ds, val_ds, class_names = build_datasets(args.data_dir, args.img_size, args.batch_size)
    model = build_model(num_classes=len(class_names), img_size=args.img_size, lr=args.lr, train_base=args.train_base)

    os.makedirs("models", exist_ok=True)
    with open("models/labels.txt", "w", encoding="utf-8") as f:
        for c in class_names:
            f.write(str(c) + "\n")

    ckp = ModelCheckpoint("models/model.h5", monitor="val_accuracy", save_best_only=True, mode="max", verbose=1)
    es = EarlyStopping(monitor="val_accuracy", patience=5, restore_best_weights=True)
    rlrop = ReduceLROnPlateau(monitor="val_accuracy", factor=0.5, patience=2, verbose=1)

    model.fit(train_ds, validation_data=val_ds, epochs=args.epochs, callbacks=[ckp, es, rlrop])

    # Save final model (best already saved by checkpoint)
    model.save("models/model.h5")
    print("Training complete. Model and labels saved to 'models/'.")

if __name__ == "__main__":
    main()
