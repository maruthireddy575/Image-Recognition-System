
# Image Recognition System (TensorFlow + OpenCV + Flask)

A complete image classification web app. Users upload an image and get real-time predictions.
- **Model**: Transfer learning with MobileNetV2 (TensorFlow/Keras)
- **Preprocessing**: OpenCV
- **Web**: Flask

---

## Quick Start (Pretrained ImageNet mode)

This runs immediately using a MobileNetV2 model pretrained on ImageNet (1000 common object categories).

```bash
cd image_recognition_app
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python run.py
# open http://127.0.0.1:5000
```

> If you later train your own model, place `models/model.h5` and `models/labels.txt` in the `models/` folder.
> The app will automatically switch to your custom classes.

---

## Train Your Own Model (optional)

Prepare your dataset:
```
data/
  train/
    cat/
    dog/
  val/
    cat/
    dog/
```

Train:
```bash
python train.py --epochs 10 --img-size 224 --batch-size 32 --lr 0.0005
# optionally fine-tune base:
# python train.py --epochs 10 --train-base
```

This saves:
- `models/model.h5`
- `models/labels.txt` (one class name per line)

Restart the web app and it will use your custom model/classes.

---

## Project Structure
```
image_recognition_app/
├─ app/
│  ├─ __init__.py
│  ├─ app.py
│  ├─ utils.py
│  ├─ templates/
│  │  └─ index.html
│  └─ static/
│     └─ style.css
├─ data/
│  ├─ train/  # put your dataset here
│  └─ val/    # put your dataset here
├─ models/
│  ├─ model.h5     # (created after training)
│  └─ labels.txt   # (created after training)
├─ train.py
├─ run.py
├─ requirements.txt
└─ README.md
```

---

## Notes
- Uploaded files are placed in `uploads/` (created at runtime).
- Default secret key is a dev value; set `FLASK_SECRET_KEY` for production.
- For production, run with Gunicorn: `gunicorn -w 2 -b 0.0.0.0:5000 run:app`

Enjoy!
